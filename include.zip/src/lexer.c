#include <stdio.h>
#include <ctype.h>

#include "lexer.h"
#include "token.h"

void lexer(const char *input, token_list_t *list)
{
    int i = 0;
    int j;
    char word[MAX_TOKEN_LEN];

    token_list_init(list);

    while (input[i] != '\0')
    {
        /* Skip spaces */
        if (isspace((unsigned char)input[i]))
        {
            i++;
            continue;
        }

        /* Pipe */
        if (input[i] == '|')
        {
            token_add(list, TOKEN_PIPE, "|");
            i++;
            continue;
        }

        /* Input redirection */
        if (input[i] == '<')
        {
            token_add(list, TOKEN_INPUT, "<");
            i++;
            continue;
        }

        /* Output / Append redirection */
        if (input[i] == '>')
        {
            if (input[i + 1] == '>')
            {
                token_add(list, TOKEN_APPEND, ">>");
                i += 2;
            }
            else
            {
                token_add(list, TOKEN_OUTPUT, ">");
                i++;
            }

            continue;
        }

        /* Background */
        if (input[i] == '&')
        {
            token_add(list, TOKEN_BACKGROUND, "&");
            i++;
            continue;
        }

        /* Single quoted string */
        if (input[i] == '\'')
        {
            i++;
            j = 0;

            while (input[i] != '\0' && input[i] != '\'')
            {
                if (j < MAX_TOKEN_LEN - 1)
                {
                    word[j++] = input[i];
                }

                i++;
            }

            if (input[i] != '\'')
            {
                printf("Lexer Error: Unterminated single quote\n");
                return;
            }

            word[j] = '\0';

            token_add(list, TOKEN_WORD, word);

            i++;
            continue;
        }

        /* Double quoted string */
        if (input[i] == '"')
        {
            i++;
            j = 0;

            while (input[i] != '\0' && input[i] != '"')
            {
                if (j < MAX_TOKEN_LEN - 1)
                {
                    word[j++] = input[i];
                }

                i++;
            }

            if (input[i] != '"')
            {
                printf("Lexer Error: Unterminated double quote\n");
                return;
            }

            word[j] = '\0';

            token_add(list, TOKEN_WORD, word);

            i++;
            continue;
        }

        /* Normal word */
        j = 0;

        while (input[i] != '\0')
        {
            if (isspace((unsigned char)input[i]))
            {
                break;
            }

            if (input[i] == '|' ||
                input[i] == '<' ||
                input[i] == '>' ||
                input[i] == '&')
            {
                break;
            }

            /* Single quote inside a word */
            if (input[i] == '\'')
            {
                i++;

                while (input[i] != '\0' && input[i] != '\'')
                {
                    if (j < MAX_TOKEN_LEN - 1)
                    {
                        word[j++] = input[i];
                    }

                    i++;
                }

                if (input[i] != '\'')
                {
                    printf("Lexer Error: Unterminated single quote\n");
                    return;
                }

                i++;
                continue;
            }

            /* Double quote inside a word */
            if (input[i] == '"')
            {
                i++;

                while (input[i] != '\0' && input[i] != '"')
                {
                    if (j < MAX_TOKEN_LEN - 1)
                    {
                        word[j++] = input[i];
                    }

                    i++;
                }

                if (input[i] != '"')
                {
                    printf("Lexer Error: Unterminated double quote\n");
                    return;
                }

                i++;
                continue;
            }

            if (j < MAX_TOKEN_LEN - 1)
            {
                word[j++] = input[i];
            }

            i++;
        }

        word[j] = '\0';

        if (j > 0)
        {
            token_add(list, TOKEN_WORD, word);
        }
    }

    token_add(list, TOKEN_END, "");
}
