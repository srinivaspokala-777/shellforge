#include <stdio.h>
#include <unistd.h>

int main()
{
    if (fork() == 0)
    {
        printf("Child exiting\n");
        return 0;
    }

    printf("before sleep\n");
    sleep(1000);
    printf("after sleep\n");

    return 0;
}

