#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

#include "executor.h"
#include "builtin.h"

int execute_command(command_t *cmd)
{
    pid_t pid;
    int status;

    if (cmd == NULL || cmd->argc == 0) {
        return -1;
    }

    if (is_builtin(cmd)) {
        return execute_builtin(cmd);
    }

    pid = fork();
    if (pid < 0) {
        perror("fork");
        return -1;
    }

    if (pid == 0) {
        execvp(cmd->argv[0], cmd->argv);
        perror(cmd->argv[0]);
        exit(EXIT_FAILURE);
    }

    if (waitpid(pid, &status, 0) == -1) {
        perror("waitpid");
        return -1;
 }

    if (WIFEXITED(status)) {
        return WEXITSTATUS(status);
    }
    if (WIFSIGNALED(status)) {
        fprintf(stderr, "Process terminated by signal %d\n", WTERMSIG(status));
        return -1;
    }

    return 0;
}

int execute_pipeline(pipeline_t *pipeline)
{
    int n = pipeline->command_count;
    int pipefds[2 * (n - 1)];

    // create pipes
    for (int i = 0; i < n - 1; i++) {
        if (pipe(pipefds + i*2) < 0) {
            perror("pipe");
            return -1;
        }
    }

    for (int i = 0; i < n; i++) {
        pid_t pid = fork();
        if (pid == 0) {
            if (i > 0) {
                dup2(pipefds[(i-1)*2], STDIN_FILENO);
            }
            if (i < n - 1) {
                dup2(pipefds[i*2 + 1], STDOUT_FILENO);
            }
            for (int j = 0; j < 2*(n-1); j++) {
 close(pipefds[j]);
            }
            if (is_builtin(&pipeline->commands[i])) {
                exit(execute_builtin(&pipeline->commands[i]));
            } else {
                execvp(pipeline->commands[i].argv[0], pipeline->commands[i].argv);
                perror(pipeline->commands[i].argv[0]);
                exit(EXIT_FAILURE);
            }
        } else if (pid < 0) {
            perror("fork");
            return -1;
        }
    }

    for (int j = 0; j < 2*(n-1); j++) {
        close(pipefds[j]);
    }

    for (int i = 0; i < n; i++) {
        wait(NULL);
    }

    return 0;
}
