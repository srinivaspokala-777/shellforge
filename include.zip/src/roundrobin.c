#include <stdio.h>

typedef struct
{
    int id;
    int bt;
    int wt;
    int tat;
    int rt;
    int ct;
} process;

int i;
int tq, at = 0;

void rr(process p[10], int n)
{
    int sum_wt = 0;
    int sum_tt = 0;
    int count = 0;
    int wt = 0;

    float avg_wt;
    float avg_tat;

    printf("Enter Time Quantum: ");
    scanf("%d", &tq);

    /* Initialize remaining time */
    for (i = 0; i < n; i++)
    {
        p[i].rt = p[i].bt;
        p[i].ct = 0;
        p[i].wt = 0;
        p[i].tat = 0;
    }

    /* Round Robin scheduling */
    while (count < n)
    {
        for (i = 0; i < n; i++)
        {
            if (p[i].rt > 0)
            {
                if (p[i].rt <= tq)
                {
                    wt += p[i].rt;
                    p[i].ct = wt;
                    p[i].rt = 0;
                    count++;
                }
                else
                {
                    wt += tq;
                    p[i].rt -= tq;
                }
            }
        }
    }

    /* Calculate Turnaround Time */
    for (i = 0; i < n; i++)
    {
        p[i].tat = p[i].ct - at;
    }

    /* Calculate Waiting Time */
    for (i = 0; i < n; i++)
    {
        p[i].wt = p[i].tat - p[i].bt;
    }

    /* Calculate sums */
    for (i = 0; i < n; i++)
    {
        sum_wt += p[i].wt;
        sum_tt += p[i].tat;
    }

    /* Calculate averages */
    avg_wt = (float)sum_wt / n;
    avg_tat = (float)sum_tt / n;

    /* Display results */
    printf("\n----------------------------------------\n");
    printf("      ROUND ROBIN SCHEDULING\n");
    printf("----------------------------------------\n");

    printf("\nPID\tBT\tWT\tTAT\tCT\n");

    for (i = 0; i < n; i++)
    {
        printf("P%d\t%d\t%d\t%d\t%d\n",
               p[i].id,
               p[i].bt,
               p[i].wt,
               p[i].tat,
               p[i].ct);
    }

    printf("\nAverage Waiting Time    = %.2f", avg_wt);
    printf("\nAverage Turnaround Time = %.2f\n", avg_tat);
}
