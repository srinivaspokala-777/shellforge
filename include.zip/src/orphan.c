#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>

int main()
{
    if (fork() == 0)
    {
        sleep(1000);
        printf("Child still running\n");
    }
    else
    {
        exit(0);
    }

    return 0;
}

